import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  // Protect workspace routes
  if (request.nextUrl.pathname.startsWith('/workspace')) {
    const projectId = request.cookies.get('currentProjectId');
    
    if (!projectId) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: '/workspace/:path*',
}
'use client';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface StepOneProps {
  data: {
    genre: string;
    audience: string;
    style: string;
    storyLength: string;
  };
  updateData: (data: Partial<typeof data>) => void;
}

export default function OnboardingStepOne({ data, updateData }: StepOneProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="genre">Genre</Label>
        <Select
          value={data.genre}
          onValueChange={(value) => updateData({ genre: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select genre" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="fantasy">Fantasy</SelectItem>
            <SelectItem value="sci-fi">Science Fiction</SelectItem>
            <SelectItem value="mystery">Mystery</SelectItem>
            <SelectItem value="romance">Romance</SelectItem>
            <SelectItem value="thriller">Thriller</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="audience">Target Audience</Label>
        <Select
          value={data.audience}
          onValueChange={(value) => updateData({ audience: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select audience" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="middle-grade">Middle Grade</SelectItem>
            <SelectItem value="young-adult">Young Adult</SelectItem>
            <SelectItem value="adult">Adult</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="style">Writing Style</Label>
        <Select
          value={data.style}
          onValueChange={(value) => updateData({ style: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select style" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="literary">Literary</SelectItem>
            <SelectItem value="commercial">Commercial</SelectItem>
            <SelectItem value="experimental">Experimental</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="storyLength">Story Length</Label>
        <Select
          value={data.storyLength}
          onValueChange={(value) => updateData({ storyLength: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select length" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="short-story">Short Story</SelectItem>
            <SelectItem value="novella">Novella</SelectItem>
            <SelectItem value="novel">Novel</SelectItem>
            <SelectItem value="series">Series</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
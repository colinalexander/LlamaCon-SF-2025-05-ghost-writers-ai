'use client';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface StepTwoProps {
  data: {
    title: string;
    description: string;
    tone: string;
  };
  updateData: (data: Partial<typeof data>) => void;
}

export default function OnboardingStepTwo({ data, updateData }: StepTwoProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Story Title</Label>
        <Input
          id="title"
          value={data.title}
          onChange={(e) => updateData({ title: e.target.value })}
          placeholder="Enter your story title"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">One-Line Description</Label>
        <Textarea
          id="description"
          value={data.description}
          onChange={(e) => updateData({ description: e.target.value })}
          placeholder="Summarize your story in one sentence"
          rows={3}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="tone">Story Tone</Label>
        <Select
          value={data.tone}
          onValueChange={(value) => updateData({ tone: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select tone" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="dark">Dark & Gritty</SelectItem>
            <SelectItem value="light">Light & Hopeful</SelectItem>
            <SelectItem value="humorous">Humorous</SelectItem>
            <SelectItem value="serious">Serious</SelectItem>
            <SelectItem value="mysterious">Mysterious</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
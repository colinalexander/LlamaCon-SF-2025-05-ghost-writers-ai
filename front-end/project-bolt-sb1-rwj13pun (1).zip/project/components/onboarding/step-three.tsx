'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';

const coachMap = {
  fantasy: {
    name: 'Aria',
    image: 'https://images.pexels.com/photos/7681731/pexels-photo-7681731.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Fantasy & Worldbuilding Expert',
  },
  'sci-fi': {
    name: 'Nova',
    image: 'https://images.pexels.com/photos/8438923/pexels-photo-8438923.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Science Fiction & Technology Specialist',
  },
  mystery: {
    name: 'Sherlock',
    image: 'https://images.pexels.com/photos/8489923/pexels-photo-8489923.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Mystery & Crime Writing Pro',
  },
  romance: {
    name: 'Rose',
    image: 'https://images.pexels.com/photos/7681734/pexels-photo-7681734.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Romance & Character Development Expert',
  },
  thriller: {
    name: 'Alex',
    image: 'https://images.pexels.com/photos/8489924/pexels-photo-8489924.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Thriller & Suspense Specialist',
  },
};

interface StepThreeProps {
  genre: string;
}

export default function OnboardingStepThree({ genre }: StepThreeProps) {
  const coach = coachMap[genre as keyof typeof coachMap] || coachMap.fantasy;

  return (
    <div className="text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <h2 className="text-xl font-semibold mb-4">Meet Your Writing Coach</h2>
        
        <div className="relative w-32 h-32 mx-auto mb-6">
          <Image
            src={coach.image}
            alt={coach.name}
            width={128}
            height={128}
            className="rounded-full object-cover"
          />
        </div>

        <div className="space-y-2">
          <h3 className="text-lg font-medium">{coach.name}</h3>
          <p className="text-muted-foreground">{coach.description}</p>
        </div>

        <div className="mt-8 p-6 bg-muted rounded-lg">
          <p className="text-sm text-muted-foreground">
            {coach.name} will help you develop your story, maintain consistency,
            and overcome writer's block. They're available 24/7 to assist with
            brainstorming, character development, and scene planning.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
import GhostWritersWebsite from "@/components/ghost-writers/website";

export default function Page() {
  return <GhostWritersWebsite />;
}
/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: { 
    unoptimized: true 
  },
  experimental: {
    serverComponentsExternalPackages: [
      '@libsql/client',
      '@libsql/linux-x64-gnu'
    ]
  },
  webpack: (config, { isServer }) => {
    if (!isServer) {
      // Client-side configuration
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        path: false,
        'better-sqlite3': false,
        'sqlite3': false,
        '@libsql/client': false,
        '@libsql/linux-x64-gnu': false,
        '@libsql/client/node_modules/@libsql/libsql-wasm-experimental': false,
        '@libsql/libsql-wasm-experimental': false
      };
    } else {
      // Server-side configuration
      config.resolve.fallback = {
        ...config.resolve.fallback,
        'better-sqlite3': false,
        'sqlite3': false
      };
    }
    
    // Disable webpack cache to prevent stale builds
    config.cache = false;
    return config;
  }
};

module.exports = nextConfig;
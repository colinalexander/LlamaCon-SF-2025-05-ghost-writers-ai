import Database from 'better-sqlite3';
import path from 'path';

let db: Database.Database | null = null;

// Initialize database connection
function getDb() {
  if (typeof window !== 'undefined') {
    throw new Error('Database operations can only be performed on the server side');
  }

  if (!db) {
    db = new Database(path.join(process.cwd(), 'ghost-writers.db'));
    
    // Initialize database with required tables
    db.exec(`
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        genre TEXT,
        audience TEXT,
        style TEXT,
        story_length TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }

  return db;
}

export async function getProjects() {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM projects ORDER BY created_at DESC');
  return stmt.all();
}

export async function createProject(project: any) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO projects (id, title, description, genre, audience, style, story_length)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  
  const projectId = crypto.randomUUID();
  
  stmt.run(
    projectId,
    project.title,
    project.description,
    project.genre,
    project.audience,
    project.style,
    project.story_length
  );

  return projectId;
}

export async function initDb() {
  getDb(); // This will initialize the database if it hasn't been initialized
  return true;
}
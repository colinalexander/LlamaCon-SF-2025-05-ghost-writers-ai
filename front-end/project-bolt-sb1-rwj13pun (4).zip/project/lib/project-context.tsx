'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { toast } from 'sonner';

interface ProjectContextType {
  projectId: string | null;
  setProjectId: (id: string | null) => void;
  clearProject: () => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projectId, setProjectId] = useState<string | null>(null);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Restore project ID from localStorage on mount
    const storedProjectId = localStorage.getItem('currentProjectId');
    if (storedProjectId) {
      setProjectId(storedProjectId);
    }
  }, []);

  useEffect(() => {
    // Protect workspace routes
    if (pathname?.startsWith('/workspace') && !projectId) {
      toast.error('Please select a project first');
      router.push('/dashboard');
    }
  }, [pathname, projectId, router]);

  const handleSetProjectId = (id: string | null) => {
    setProjectId(id);
    if (id) {
      localStorage.setItem('currentProjectId', id);
    } else {
      localStorage.removeItem('currentProjectId');
    }
  };

  const clearProject = () => {
    setProjectId(null);
    localStorage.removeItem('currentProjectId');
    router.push('/dashboard');
  };

  return (
    <ProjectContext.Provider 
      value={{ 
        projectId, 
        setProjectId: handleSetProjectId,
        clearProject 
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
}